This directory contains scripts that are used in building, managing,
testing, and other forms of work in a Zulip development environment.
Note that tools that are also useful in production belong in
`scripts/` or should be Django management commands.

For more details, see
https://zulip.readthedocs.io/en/latest/overview/directory-structure.html.
