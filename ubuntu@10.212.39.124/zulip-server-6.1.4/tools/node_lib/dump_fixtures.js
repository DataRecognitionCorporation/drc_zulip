"use strict";

const events = require("../../frontend_tests/node_tests/lib/events");

console.info(JSON.stringify(events.fixtures, null, 4));
