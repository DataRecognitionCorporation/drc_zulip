# Zulip Markdown documentation hosted elsewhere

The Markdown files in this directory ( /zulip/docs ) are not intended
to be read on GitHub. Instead, visit our
[ReadTheDocs](https://zulip.readthedocs.io/en/latest/index.html) to
read the Zulip documentation.
