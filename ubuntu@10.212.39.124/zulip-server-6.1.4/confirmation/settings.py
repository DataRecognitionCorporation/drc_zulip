# Copyright: (c) 2008, Jarek Zgoda <jarek.zgoda@gmail.com>

__revision__ = "$Id: settings.py 12 2008-11-23 19:38:52Z jarek.zgoda $"

STATUS_USED = 1
STATUS_REVOKED = 2
