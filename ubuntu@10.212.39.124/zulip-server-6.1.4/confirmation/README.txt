===================
Django Confirmation
===================

This is a generic object confirmation system for Django applications.

For installation instructions, see the file "INSTALL.txt" in this
directory; for instructions on how to use this application, and on
what it provides, see the file "overview.txt" in the "docs/"
directory.
